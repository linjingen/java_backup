
public interface PathGenerator {
	
	public Path getPath();

}
