public class Run{

    private double rate;
    private int N;
    private double sigma;
    private double S0;
    private double strikePrice;
    private double accuracy;
    private double year;

    public double getRate(){
        return rate;
    }
    public int getN(){
        return N;
    }
    public double getSigma(){
        return sigma;
    }
    public double getS0(){
        return S0;
    }
    public double getStrikePrice(){
        return strikePrice;
    }
    public double getAccuracy(){
        return accuracy;
    }
    public double getYear(){
        return year;
    }

    public Run(double rate, int N, double sigma, double S0, double strikePrice, double accuracy, double year){
        this.rate = rate;
        this.N = N;
        this.sigma = sigma;
        this.S0 = S0;
        this.strikePrice = strikePrice;
        this.accuracy = accuracy;
        this.year = year;
    }

    public static void main(String[] args){
        Run run = new Run(0.01, 252, 0.1, 100, 100, 0.01, 1);
        RandomVectorGenerator rvg = new AntiTheticGRVGenerator(run.getN());
        PathGenerator gbm = new GBMRandomPathGenerator(run.getYear(), run.getRate(), run.getN(), run.getSigma(), run.getS0(), rvg);
        PayOut eco = new EuropeanCallOption(run.getStrikePrice());
        PayOut apo = new AsianPutOption(run.getStrikePrice());
        SimulationManager simulation_eco = new SimulationManager(gbm,eco,run.getAccuracy());
        SimulationManager simulation_apo = new SimulationManager(gbm,apo,run.getAccuracy());
        double ave_Payout_eco = simulation_eco.doSimulation();
        double ave_Payout_apo = simulation_apo.doSimulation();

        double price_eco = Math.exp(-run.getRate()*run.getYear())*ave_Payout_eco;
        double price_apo = Math.exp(-run.getRate()*run.getYear())*ave_Payout_apo;
        System.out.println("European Call Option Price :"+ price_eco);
        System.out.println("Asian Put Option Price :"+ price_apo);

    }
}
