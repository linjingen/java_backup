
public interface Path {
	
	public double[] getPrices();

}
