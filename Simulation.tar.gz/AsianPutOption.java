public class AsianPutOption implements PayOut{

    private double K;

    public AsianPutOption(double K){

        this.K = K;
    }

    public double getPayout(Path path){

        double[] prices = path.getPrices();
        double sum = 0;
        for(int i = 0; i<prices.length; ++i){
            sum = sum + prices[i];
        }
        return Math.max(K - sum/prices.length, 0);
    }
}
