
public interface RandomVectorGenerator {
	
	public double[] getVector();

}
