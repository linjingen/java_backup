public class SimulationManager{

    protected PathGenerator pathgenerator;
    protected PayOut payout;
    protected double accuracy;

    public SimulationManager(PathGenerator pg, PayOut po, double ac){
        this.pathgenerator = pg;
        this.payout = po;
        this.accuracy = ac;
    }

    public double doSimulation(){
        double optionPrice;
        double sum_sqr_ave = 0;
        double sum_ave_sqr = 0;
        double variance = 0;
        double averageArith = 0;
        double averageSqur = 0; 
        double totalSimulationNum = 1;

        while(3*Math.sqrt(variance)/Math.sqrt(totalSimulationNum) > accuracy || totalSimulationNum < 10000){
            optionPrice = payout.getPayout(pathgenerator.getPath());
            sum_sqr_ave += Math.pow(optionPrice,2);
            sum_ave_sqr += optionPrice;
            averageSqur = sum_sqr_ave/totalSimulationNum;
            averageArith = sum_ave_sqr/totalSimulationNum;
            variance = averageSqur - Math.pow(averageArith,2);
            totalSimulationNum ++;
        }
        System.out.println("Total Simulation Number is " + totalSimulationNum);
        return averageArith;
    }
}
